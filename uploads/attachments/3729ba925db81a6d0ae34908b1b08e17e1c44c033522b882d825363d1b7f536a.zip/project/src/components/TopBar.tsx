import { MessageSquare, Pen, Layers, Plus, Headphones, ChevronDown, Bell, Search, MoreVertical } from 'lucide-react';

interface TopBarProps {
  userName?: string;
  userAvatar?: string;
  userTitle?: string;
}

export default function TopBar({ userName = 'Rahat', userAvatar, userTitle = 'Software Engineer' }: TopBarProps) {
  return (
    <div className="bg-[#1A1D21] border-b border-white/5 border-t border-white/10 flex-shrink-0">
      <div className="flex items-center justify-between px-4 py-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <img
              src={userAvatar || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100'}
              alt={userName}
              className="w-5 h-5 rounded object-cover"
            />
            <span className="text-white font-semibold text-sm">{userName}</span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button className="p-2 hover:bg-white/5 rounded transition-colors text-gray-300">
            <Headphones size={18} />
          </button>
          <button className="p-2 hover:bg-white/5 rounded transition-colors text-gray-300">
            <ChevronDown size={18} />
          </button>
          <button className="p-2 hover:bg-white/5 rounded transition-colors text-gray-300">
            <Bell size={18} />
          </button>
          <button className="p-2 hover:bg-white/5 rounded transition-colors text-gray-300">
            <Search size={18} />
          </button>
          <button className="p-2 hover:bg-white/5 rounded transition-colors text-gray-300">
            <MoreVertical size={18} />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-4 px-4 pb-2">
        <button className="flex items-center gap-2 text-white border-b-2 border-white pb-2 text-sm font-medium">
          <MessageSquare size={16} />
          <span>Messages</span>
        </button>
        <button className="flex items-center gap-2 text-gray-400 hover:text-white pb-2 text-sm transition-colors">
          <Pen size={16} />
          <span>Add canvas</span>
        </button>
        <button className="flex items-center gap-2 text-gray-400 hover:text-white pb-2 text-sm transition-colors">
          <Layers size={16} />
          <span>Files</span>
        </button>
        <button className="text-gray-400 hover:text-white pb-2 transition-colors">
          <Plus size={18} />
        </button>
      </div>
    </div>
  );
}
