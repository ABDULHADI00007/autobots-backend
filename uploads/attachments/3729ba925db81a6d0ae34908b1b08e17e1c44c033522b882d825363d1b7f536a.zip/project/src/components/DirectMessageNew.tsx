import MainLayout from './MainLayout';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Link,
  List,
  ListOrdered,
  Code,
  AlignLeft,
  Plus,
  Type,
  Smile,
  AtSign,
  Video,
  Mic,
  Paperclip,
  Send,
  ExternalLink,
  BellOff
} from 'lucide-react';

export default function DirectMessageNew() {
  const userName = 'Rahat';
  const userAvatar = 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400';
  const userTitle = 'Software Engineer';

  return (
    <MainLayout userName={userName} userAvatar={userAvatar} userTitle={userTitle}>
      <div className="flex flex-col h-full">
        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="max-w-3xl">
            <div className="flex items-start gap-4 mb-6">
              <img
                src={userAvatar}
                alt={userName}
                className="w-32 h-32 rounded-lg object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-white text-xl font-bold">{userName}</h2>
                  <ExternalLink size={16} className="text-gray-400" />
                </div>
                <p className="text-gray-400 text-sm mb-4">{userTitle}</p>
              </div>
            </div>

            <div className="text-gray-300 text-sm mb-4">
              This conversation is just between{' '}
              <span className="text-[#1D9BD1] hover:underline cursor-pointer">@{userName}</span>{' '}
              and you. Check out their profile to learn more about them.
            </div>

            <button className="px-4 py-2 bg-transparent border border-gray-600 hover:border-gray-500 text-white rounded text-sm font-medium transition-colors mb-8">
              View Profile
            </button>

            <div className="flex items-center justify-center my-6">
              <div className="flex-1 h-px bg-white/10" />
              <span className="px-4 text-xs text-gray-500 font-medium">Monday, February 3</span>
              <div className="flex-1 h-px bg-white/10" />
            </div>

            <div className="flex items-start gap-3 bg-[#2C2D30] rounded-lg p-4 mb-6">
              <BellOff size={18} className="text-gray-400 mt-0.5" />
              <p className="text-sm text-gray-300">
                <span className="font-semibold">{userName}</span> has paused their notifications
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 px-4 py-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-[#1A1D21] border border-gray-700 rounded-lg">
              <div className="flex items-center gap-1 px-3 py-2 border-b border-gray-700">
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Bold size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Italic size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Underline size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Strikethrough size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Link size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <List size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <ListOrdered size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <AlignLeft size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Code size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <AlignLeft size={16} />
                </button>
              </div>

              <div className="px-4 py-3">
                <input
                  type="text"
                  placeholder={`Message ${userName}`}
                  className="w-full bg-transparent text-gray-300 placeholder-gray-500 outline-none text-sm"
                />
              </div>

              <div className="flex items-center justify-between px-3 py-2">
                <div className="flex items-center gap-1">
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Plus size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Type size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Smile size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <AtSign size={18} />
                  </button>
                  <div className="w-px h-4 bg-gray-700 mx-1" />
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Video size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Mic size={18} />
                  </button>
                  <div className="w-px h-4 bg-gray-700 mx-1" />
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Paperclip size={18} />
                  </button>
                </div>

                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
