import { Search, ArrowLeft, ArrowRight, RotateCcw, HelpCircle } from 'lucide-react';
import LeftIconBar from './LeftIconBar';
import LeftSidebar from './LeftSidebar';
import TopBar from './TopBar';

interface MainLayoutProps {
  children: React.ReactNode;
  userName?: string;
  userAvatar?: string;
  userTitle?: string;
}

export default function MainLayout({ children, userName, userAvatar, userTitle }: MainLayoutProps) {
  return (
    <div className="flex h-screen bg-[#1A1D21] overflow-hidden flex-col">
      <div className="bg-[#3C2451] px-4 py-2 border-b border-white/5 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400">
              <ArrowLeft size={18} />
            </button>
            <button className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400">
              <ArrowRight size={18} />
            </button>
            <button className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400">
              <RotateCcw size={18} />
            </button>
          </div>

          <div className="flex-1 mx-4 max-w-lg">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                placeholder="Search SolveVare"
                className="w-full bg-[#4A154B]/50 border border-gray-600 rounded px-3 pl-9 py-1.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-gray-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400">
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-pink-400 to-yellow-400" />
            </button>
            <button className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400">
              <HelpCircle size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden min-h-0">
        <LeftIconBar />
        <LeftSidebar />

        <div className="flex-1 flex flex-col overflow-hidden min-h-0">
          <TopBar userName={userName} userAvatar={userAvatar} userTitle={userTitle} />
          <main className="flex-1 overflow-y-auto hide-scrollbar">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}
