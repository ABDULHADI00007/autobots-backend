import { useState } from 'react';
import { ChevronDown, Rocket, Headphones, LayoutGrid, Star, ChevronRight, ChevronDown as ChevronDownIcon, Hash } from 'lucide-react';

interface UserItemProps {
  name: string;
  avatar: string;
  active?: boolean;
  status?: 'online' | 'away' | 'offline';
}

function UserItem({ name, avatar, active, status = 'online' }: UserItemProps) {
  return (
    <div
      className={`flex items-center gap-2 px-3 py-1 rounded cursor-pointer transition-colors ${
        active ? 'bg-[#1164A3]' : 'hover:bg-white/5'
      }`}
    >
      <div className="relative">
        <img
          src={avatar}
          alt={name}
          className="w-5 h-5 rounded object-cover"
        />
        <div
          className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#1A1D21] ${
            status === 'online'
              ? 'bg-green-500'
              : status === 'away'
              ? 'bg-white'
              : 'bg-transparent border-gray-500'
          }`}
        />
      </div>
      <span className="text-[#D1D2D3] text-sm">{name}</span>
    </div>
  );
}

export default function LeftSidebar() {
  const [channelsExpanded, setChannelsExpanded] = useState(true);
  const [directMessagesExpanded, setDirectMessagesExpanded] = useState(true);

  return (
    <div className="w-[260px] bg-[#1A1D21] flex flex-col h-full flex-shrink-0 border-r border-white/10">
      <div className="p-3 border-b border-white/5 flex-shrink-0">
        <button className="flex items-center justify-between w-full px-3 py-2 text-white font-bold text-lg hover:bg-white/5 rounded transition-colors">
          <span>SolveVare</span>
          <ChevronDown size={18} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar">
        <div className="p-3">
          <button className="w-full flex items-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 rounded text-white text-sm font-medium transition-colors">
            <Rocket size={16} />
            <span>Upgrade Plan</span>
          </button>
        </div>

        <div className="px-3 pb-3">
          <button className="flex items-center gap-2 w-full px-3 py-1.5 text-[#D1D2D3] hover:bg-white/5 rounded transition-colors text-sm">
            <Headphones size={18} />
            <span>Huddles</span>
          </button>
          <button className="flex items-center gap-2 w-full px-3 py-1.5 text-[#D1D2D3] hover:bg-white/5 rounded transition-colors text-sm">
            <LayoutGrid size={18} />
            <span>Directories</span>
          </button>
        </div>

        <div className="px-3 pb-3">
          <button className="flex items-center gap-2 w-full px-3 py-1.5 text-[#D1D2D3] hover:bg-white/5 rounded transition-colors text-sm">
            <Star size={18} />
            <span>Starred</span>
          </button>
          <div className="px-3 py-2 text-xs text-gray-500">
            Drag and drop important stuff here
          </div>
        </div>

        <div className="px-3 pb-2">
          <button
            onClick={() => setChannelsExpanded(!channelsExpanded)}
            className="flex items-center gap-1 w-full px-3 py-1 text-[#D1D2D3] hover:bg-white/5 rounded transition-colors text-sm"
          >
            <ChevronRight
              size={16}
              className={`transition-transform ${channelsExpanded ? 'rotate-90' : ''}`}
            />
            <span>Channels</span>
          </button>
          {channelsExpanded && (
            <div className="pl-6 mt-1 space-y-0.5">
              <div className="flex items-center gap-2 px-3 py-1 text-[#D1D2D3] hover:bg-white/5 rounded cursor-pointer text-sm">
                <Hash size={16} />
                <span>general</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 text-[#D1D2D3] hover:bg-white/5 rounded cursor-pointer text-sm">
                <Hash size={16} />
                <span>frontend</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 text-[#D1D2D3] hover:bg-white/5 rounded cursor-pointer text-sm">
                <Hash size={16} />
                <span>backend</span>
              </div>
            </div>
          )}
        </div>

        <div className="px-3">
          <button
            onClick={() => setDirectMessagesExpanded(!directMessagesExpanded)}
            className="flex items-center gap-1 w-full px-3 py-1 text-[#D1D2D3] hover:bg-white/5 rounded transition-colors text-sm mb-1"
          >
            <ChevronDownIcon
              size={16}
              className={`transition-transform ${directMessagesExpanded ? '' : '-rotate-90'}`}
            />
            <span>Direct messages</span>
          </button>
          {directMessagesExpanded && (
            <div className="space-y-0.5">
              <UserItem
                name="Rahat"
                avatar="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100"
                active
                status="online"
              />
              <UserItem
                name="Rafay Imran"
                avatar="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="away"
              />
              <UserItem
                name="sufyan"
                avatar="https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="online"
              />
              <UserItem
                name="ahmer khan"
                avatar="https://images.pexels.com/photos/1484794/pexels-photo-1484794.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="online"
              />
              <UserItem
                name="Ahmer khan"
                avatar="https://images.pexels.com/photos/1520760/pexels-photo-1520760.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="online"
              />
              <UserItem
                name="arbab"
                avatar="https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="offline"
              />
              <UserItem
                name="ebadu"
                avatar="https://images.pexels.com/photos/1680172/pexels-photo-1680172.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="online"
              />
              <UserItem
                name="Syed Ahsan"
                avatar="https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100"
                status="online"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
