import MainLayout from './MainLayout';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Link,
  List,
  ListOrdered,
  Code,
  AlignLeft,
  Plus,
  Type,
  Smile,
  AtSign,
  Video,
  Mic,
  Paperclip,
  Send,
  BellOff,
  ChevronDown,
} from 'lucide-react';

export default function ConfigurationMessage() {
  const userName = 'Rahat';
  const userAvatar = 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400';
  const userTitle = 'Software Engineer';

  return (
    <MainLayout userName={userName} userAvatar={userAvatar} userTitle={userTitle}>
      <div className="flex flex-col h-full">
        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="max-w-3xl">
            <div className="flex items-center justify-between mb-6">
              <div className="flex-1" />
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <span>Friday, February 6th</span>
                <ChevronDown size={16} />
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="font-mono text-sm text-gray-300 bg-[#0D0D0D] rounded p-4 border border-gray-800">
                <div>EMAIL_SECURE=true</div>
                <div>EMAIL_USER=<span className="text-cyan-400">solvevare@almoinmotors.com</span></div>
                <div>EMAIL_PASS=<span className="text-cyan-400">@Solvevare2026</span></div>
                <div>EMAIL_FROM=&quot;Pair Up &lt;<span className="text-cyan-400">solvevare@almoinmotors.com</span>&gt;&quot;</div>
                <div className="mt-4">INVITE_SECRET=some_invite_secret</div>
              </div>

              <div className="flex items-start gap-3">
                <img
                  src={userAvatar}
                  alt={userName}
                  className="w-8 h-8 rounded object-cover mt-1"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold text-sm">{userName}</span>
                    <span className="text-gray-500 text-sm">8:56 PM</span>
                  </div>
                  <div className="font-mono text-sm text-gray-300 mt-2 bg-[#0D0D0D] rounded p-3 border border-gray-800">
                    <div>PORT =9000</div>
                    <div className="mt-2"># MONGO_URI=<span className="text-cyan-400">mongodb://127.0.0.1:27017/mynodeexp</span></div>
                    <div>MONGO_URI=<span className="text-cyan-400">mongodb+srv://rahatrajput786125_db_user:2Z56F2NFaryN2cqs@cluster0.fowufzp.mongodb.net/?</span></div>
                    <div className="text-cyan-400">appName=Cluster0</div>
                  </div>
                  <div className="font-mono text-sm text-gray-300 mt-2 bg-[#0D0D0D] rounded p-3 border border-gray-800">
                    <div># MONGO_URI=<span className="text-cyan-400">mongodb://localhost:27017/mynodeexp</span></div>
                    <div>REFRESH_SECRET=<span className="text-gray-500">...</span></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center my-6">
              <div className="flex-1 h-px bg-white/10" />
              <span className="px-4 text-xs text-gray-500 font-medium">Monday, February 3</span>
              <div className="flex-1 h-px bg-white/10" />
            </div>

            <div className="flex items-start gap-3 bg-[#2C2D30] rounded-lg p-4 mb-6">
              <BellOff size={18} className="text-gray-400 mt-0.5" />
              <p className="text-sm text-gray-300">
                <span className="font-semibold">{userName}</span> has paused their notifications
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 px-4 py-4 bg-[#1A1D21]">
          <div className="max-w-4xl">
            <div className="bg-[#1A1D21] border border-gray-700 rounded-lg">
              <div className="flex items-center gap-1 px-3 py-2 border-b border-gray-700">
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Bold size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Italic size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Underline size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Strikethrough size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Link size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <List size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <ListOrdered size={16} />
                </button>
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <AlignLeft size={16} />
                </button>
                <div className="w-px h-4 bg-gray-700 mx-1" />
                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Code size={16} />
                </button>
              </div>

              <div className="px-4 py-3">
                <input
                  type="text"
                  placeholder={`Message ${userName}`}
                  className="w-full bg-transparent text-gray-300 placeholder-gray-500 outline-none text-sm"
                />
              </div>

              <div className="flex items-center justify-between px-3 py-2">
                <div className="flex items-center gap-1">
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Plus size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Type size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Smile size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <AtSign size={18} />
                  </button>
                  <div className="w-px h-4 bg-gray-700 mx-1" />
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Video size={18} />
                  </button>
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Mic size={18} />
                  </button>
                  <div className="w-px h-4 bg-gray-700 mx-1" />
                  <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                    <Paperclip size={18} />
                  </button>
                </div>

                <button className="p-1.5 hover:bg-white/5 rounded text-gray-400 hover:text-white transition-colors">
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
