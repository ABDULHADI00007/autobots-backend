import { Home, MessageSquare, Bell, FolderOpen, MoreHorizontal, Plus } from 'lucide-react';

interface IconButtonProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function IconButton({ icon, label, active, onClick }: IconButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center w-full py-2 px-3 transition-colors ${
        active
          ? 'bg-purple-700/50 text-white'
          : 'text-gray-300 hover:bg-purple-900/30'
      }`}
    >
      <div className="w-6 h-6 flex items-center justify-center mb-1">
        {icon}
      </div>
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

export default function LeftIconBar() {
  return (
    <div className="w-16 bg-[#4A154B] flex flex-col items-center py-2 h-full flex-shrink-0 border-r border-white/10">
      <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mb-4 cursor-pointer">
        <span className="text-[#4A154B] font-bold text-sm">SV</span>
      </div>

      <div className="flex-1 w-full">
        <IconButton icon={<Home size={20} />} label="Home" />
        <IconButton icon={<MessageSquare size={20} />} label="DMs" active />
        <IconButton icon={<Bell size={20} />} label="Activity" />
        <IconButton icon={<FolderOpen size={20} />} label="Files" />
        <IconButton icon={<MoreHorizontal size={20} />} label="More" />
      </div>

      <div className="w-full flex flex-col items-center gap-2">
        <button className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
          <Plus size={20} />
        </button>
        <div className="w-9 h-9 rounded-lg overflow-hidden cursor-pointer">
          <img
            src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100"
            alt="User"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  );
}
