import ConfigurationMessage from './components/ConfigurationMessage';

function App() {
  return <ConfigurationMessage />;
}

export default App;
